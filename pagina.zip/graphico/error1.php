<?php
session_start();
ob_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Access</title>
<style type="text/css">

<!--

/* Gradient 2 */
.tb7 {
	width: 221px;
	background: transparent url('images/bg.jpg') no-repeat;
	color : #747862;
	height:20px;
	border:0;
	padding:4px 8px;
	margin-bottom:0px;
}
.fb7 {
    background: #EBE3CD no-repeat 5px center;
    vertical-align:middle; 
    border: 1px solid #969184;
}




body {
	background-color: #FFFFFF;
	background-image: url(images/atomos_web_ok.png);
}
.Estilo9 {font-weight: bold; font-size: 16px; color: #06708B; font-family: Verdana, Arial, Helvetica, sans-serif;}
.Estilo7 {color: #FFFFFF; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 11px; font-weight: bold; }
.Estilo10 {
	color: #FFFFFF;
	font-weight: bold;
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
-->
</style>
<script language="JavaScript" type="text/JavaScript">

var pagina="cerrar.php"
function redireccionar() 
{
location.href=pagina
} 
setTimeout ("redireccionar()",3000);

</script>
</head>

<body>
<table width="842" border="0" align="center" bordercolor="#FFFFFF" bgcolor="#FFFFFF">
  <tr bordercolor="#FFFFFF" bgcolor="#FFFFFF">
    <td width="326" bordercolor="#FFFFFF" bgcolor="#FFFFFF"><table width="288" border="0" align="center">
      <tr>
        <td>&nbsp;</td>
      </tr>
    </table></td>
    <td width="506" background="images/header.png"><table width="49" border="0" align="right">
      <tr>
        <td width="43"><div align="center"><a href="javascript:window.close();" class="Estilo7">Salir</a></div></td>
      </tr>
    </table></td>
  </tr>
  <tr bordercolor="#FFFFFF" bgcolor="#FFFFFF">
    <td colspan="2"><p>&nbsp;</p>
      <table width="600" border="0" align="center">
        <tr>
          <td><div align="center"><img src="images/letras.png" width="500" height="70" /></div></td>
        </tr>
        <tr>
          <td><div align="center">
            <p>&nbsp;</p>
            <p><img src="images/apie.png" width="249" height="94" /></p>
            <p>&nbsp;</p>
          </div></td>
        </tr>
        <tr>
          <td><div align="right" class="Estilo9">
            <div align="center"><img src="images/Copia de letras.png" width="500" height="70" /></div>
          </div></td>
        </tr>
      </table>
    <p>&nbsp;</p></td>
  </tr>
  <tr bordercolor="#FFFFFF" bgcolor="#FFFFFF">
    <td colspan="2"><div align="center"></div></td>
  </tr>
</table>
<p>&nbsp;</p>
</body>
</html>
