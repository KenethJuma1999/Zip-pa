<?php
session_start();
ob_start();
if (!isset($_SESSION['sesion_cedula'])){
	header("location:error1.php");
	return;
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Sistema Administracion de Personal</title>
<LINK REL="SHORTCUT ICON" HREF="http://localhost/reserv/images/favicon.ico">

<style type="text/css">

<!--

/* Gradient 2 */
.tb7 {
	width: 221px;
	background: transparent url('images/bg.jpg') no-repeat;
	color : #747862;
	height:20px;
	border:0;
	padding:4px 8px;
	margin-bottom:0px;
}
.fb7 {
    background: #EBE3CD no-repeat 5px center;
    vertical-align:middle; 
    border: 1px solid #969184;
}
.Estilo7 {color: #FFFFFF; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 11px; font-weight: bold; }




body {
	background-color: #D6EDF2;
	background-image: url();
}
.Estilo11 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 11px; font-weight: bold; }
.Estilo12 {font-size: 12px}
.Estilo13 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; font-weight: bold; }
.Estilo14 {color: #FFFFFF}
-->
</style>
<script language="JavaScript">

var speed = 100 
var pause = 3000
var timerID = null
var bannerRunning = false
var ar = new Array()
ar[0] = "Sistema de Administracion de Personal..."
ar[1] = "Planifique su Personal....."
ar[2] = "Consultas y Reportes 100% Rapidas."
ar[3] = "Copyright 2011 EasySoluciones."
var currentMessage = 0
var offset = 0
function stopBanner() {
if (bannerRunning)
clearTimeout(timerID)
bannerRunning = false
}
function startBanner() {
stopBanner()
showBanner()
}
function showBanner() {
var text = ar[currentMessage]
if (offset < text.length) {
if (text.charAt(offset) == " ")
offset++ 
var partialMessage = text.substring(0, offset + 1) 
window.status = partialMessage
offset++ // IE sometimes has trouble with "++offset"
timerID = setTimeout("showBanner()", speed)
bannerRunning = true
} else {
offset = 0
currentMessage++
if (currentMessage == ar.length)
currentMessage = 0
timerID = setTimeout("showBanner()", pause)
bannerRunning = true
}
}
startBanner();
// -->
</script>

</head>


<body>

<p>&nbsp;</p>
<table width="934" border="0" align="center" bordercolor="#FFFFFF" bgcolor="#FFFFFF">
  <tr bordercolor="#FFFFFF" bgcolor="#FFFFFF">
    <td width="687" rowspan="2" bordercolor="#FFFFFF" bgcolor="#FFFFFF"><img src="images/arriba.jpg" width="86" height="79" /></td>
    <td width="429" background="images/header.png"><table width="366" border="0" align="right">
      <tr>
        <td width="95"><div align="center" class="Estilo7"></div></td>
        <td width="93">&nbsp;</td>
        <td width="117"><div align="center" class="Estilo7"><a href="../administrador.php" class="Estilo7">Regresar</a></div></td>
        <td width="43"><div align="center"><a href="javascript:window.close();" class="Estilo7">Salir</a></div></td>
      </tr>
    </table></td>
  </tr>
  <tr bordercolor="#FFFFFF" bgcolor="#FFFFFF">
    <td>&nbsp;</td>
  </tr>
  <tr bordercolor="#FFFFFF" bgcolor="#FFFFFF">
    <td colspan="2"><table width="908" border="0" align="center">
      <tr>
        <td>&nbsp;</td>
        <td colspan="2"><?php
// archivos incluidos. Librer&iacute;as PHP para poder graficar.
include "FusionCharts.php";
include "Functions.php";
// Gr&aacute;fico de Barras. 4 Variables, 4 barras.
// Estas variables ser&aacute;n usadas para representar los valores de cada unas de las 4 barras.
// Inicializo las variables a utilizar.

require_once('dbconnect.php');
	
	$conn = new MySQLConn();
	$conn->connect();

	
	$sql="SELECT sum(cedula) FROM ficha_economica WHERE vpropia = 'SI';";
	$conn->sqlQuery($sql);
	$filas1 = $conn->rows[0];
	
	$sql1="SELECT sum(cedula) FROM ficha_economica WHERE varrendada = 'SI';";
	$conn->sqlQuery($sql1);
	$filas2 = $conn->rows[0];
	
	
	
	$intTotalAnio1 = $filas1;
	$intTotalAnio2 = $filas2;
	
// $strXML: Para concatenar los par&aacute;metros finales para el gr&aacute;fico.
$strXML = "";
// Armo los par&aacute;metros para el gr&aacute;fico. Todos estos datos se concatenan en una variable.
// Encabezado de la variable XML. Comienza con la etiqueta "Chart".
// caption: define el t&iacute;tulo del gr&aacute;fico.
// bgColor: define el color de fondo que tendr&aacute; el gr&aacute;fico.
// baseFontSize: Tama&ntilde;o de la fuente que se usar&aacute; en el gr&aacute;fico.
// showValues: = 1 indica que se mostrar&aacute;n los valores de cada barra. = 0 No mostrar&aacute; los valores en el gr&aacute;fico.
// xAxisName: define el texto que ir&aacute; sobre el eje X. Abajo del gr&aacute;fico. Tambi&eacute;n est&aacute; xAxisName.
$strXML = "<chart caption = 'Gr�fico Estad�stico del Personal' bgColor='#FFFFFF' baseFontSize='12' showValues='1' xAxisName='' >";
// Armado de cada barra.
// set label: asigno el nombre de cada barra.
// value: asigno el valor para cada barra.
// color: color que tendr&aacute; cada barra. Si no lo defino, tomar&aacute; colores por defecto.
$strXML .= "<set label = 'Vivienda Arrendada' value ='".$intTotalAnio2."' color = 'EA1000' />";
$strXML .= "<set label = 'Vivienda Propia' value ='".$intTotalAnio1."' color = '6D8D16' />";


// Cerramos la etiqueta "chart".
$strXML .= "</chart>";
echo renderChartHTML("Column3D.swf", "",$strXML, "ejemplo", 600, 400, false);
?></td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td width="136">&nbsp;</td>
        <td width="367">
          <p><span class="Estilo11 Estilo12"><span class="Estilo14">.........................................</span></span></p>          </td>
        <td width="286">&nbsp;</td>
        <td width="101">&nbsp;</td>
      </tr>
    </table>    </td>
  </tr>
  <tr bordercolor="#FFFFFF" bgcolor="#FFFFFF">
    <td colspan="2" background="images/footer.png"><div align="center">
      <p class="Estilo7">&nbsp;</p>
      <p class="Estilo7">Copyright 2011 CaseMager Cia. LTDA. </p>
    </div></td>
  </tr>
</table>
<p>&nbsp;</p>
</body>
</html>
