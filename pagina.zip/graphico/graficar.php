<?php
session_start();
ob_start();
if (!isset($_SESSION['sesion_cedula'])){
	header("location:error1.php");
	return;
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Sistema de Reservas Opening</title>
<LINK REL="SHORTCUT ICON" HREF="http://localhost/reserv/images/favicon.ico">

<style type="text/css">

<!--

/* Gradient 2 */
.tb7 {
	width: 221px;
	background: transparent url('images/bg.jpg') no-repeat;
	color : #747862;
	height:20px;
	border:0;
	padding:4px 8px;
	margin-bottom:0px;
}
.fb7 {
    background: #EBE3CD no-repeat 5px center;
    vertical-align:middle; 
    border: 1px solid #969184;
}
.Estilo7 {color: #FFFFFF; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 11px; font-weight: bold; }
.Estilo8 {color: #FFFFFF}




body {
	background-color: #D6EDF2;
	background-image: url(images/atomos_web_ok.png);
}
.Estilo9 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 11px;
}
.Estilo11 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 11px; font-weight: bold; }
-->
</style>
<script language="JavaScript">

var speed = 100 
var pause = 3000
var timerID = null
var bannerRunning = false
var ar = new Array()
ar[0] = "Sistema de reservaciones Online..."
ar[1] = "Reserve y Planifique a Tiempo....."
ar[2] = "Consultas y Reportes 100% Rapidas."
ar[3] = "Copyright 2011 Audit & Planning S.A."
var currentMessage = 0
var offset = 0
function stopBanner() {
if (bannerRunning)
clearTimeout(timerID)
bannerRunning = false
}
function startBanner() {
stopBanner()
showBanner()
}
function showBanner() {
var text = ar[currentMessage]
if (offset < text.length) {
if (text.charAt(offset) == " ")
offset++ 
var partialMessage = text.substring(0, offset + 1) 
window.status = partialMessage
offset++ // IE sometimes has trouble with "++offset"
timerID = setTimeout("showBanner()", speed)
bannerRunning = true
} else {
offset = 0
currentMessage++
if (currentMessage == ar.length)
currentMessage = 0
timerID = setTimeout("showBanner()", pause)
bannerRunning = true
}
}
startBanner();
// -->
</script>
<script language="JavaScript">
<!--

   function event_false() {
         window.event.returnValue = false
   }

document.onselectstart = event_false

//-->
</script>
</head>


<body>
<script language="javascript" type="text/javascript">

function MostrarFecha()
   {
   var nombres_dias = new Array("Domingo", "Lunes", "Martes", "Mi�rcoles", "Jueves", "Viernes", "S�bado")
   var nombres_meses = new Array("Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre")
   var fecha_actual = new Date()
   dia_mes = fecha_actual.getDate()		     //dia del mes
   dia_semana = fecha_actual.getDay()		//dia de la semana
   mes = fecha_actual.getMonth() + 1
   anio = fecha_actual.getFullYear()
  //escribe en pagina
   document.write(nombres_dias[dia_semana] + ", " + dia_mes + " de " + nombres_meses[mes - 1] + " de " + anio)
   }
</script>
<script language="JavaScript1.2">
<!--
function notice(){
menutext.style.left=document.body.scrollLeft+event.clientX
menutext.style.top=document.body.scrollTop+event.clientY
menutext.style.visibility="visible"
return false
}
function hidenotice(){
menutext.style.visibility="hidden"
}
//-->
</script>
<!--[if IE]>
<div id="menutext"><div url=""></div></div>
<![endif]-->
<script language="JavaScript1.2">
<!--
document.oncontextmenu=notice;
if (document.all&&window.print)
document.body.onclick=hidenotice;
//-->
</script>
<table width="1126" height="207" border="0" align="center" bordercolor="#FFFFFF" bgcolor="#FFFFFF">
  
  <tr bordercolor="#FFFFFF" bgcolor="#FFFFFF">
    <td width="687" bordercolor="#FFFFFF" bgcolor="#FFFFFF">&nbsp;</td>
    <td width="429">&nbsp;</td>
  </tr>
  <tr bordercolor="#FFFFFF" bgcolor="#FFFFFF">
    <td height="121" colspan="2"><table width="1056" border="0" align="center">
      <tr>
        <td width="123">&nbsp;</td>
        <td width="594">
<?php
// archivos incluidos. Librer&iacute;as PHP para poder graficar.
include "FusionCharts.php";
include "Functions.php";
// Gr&aacute;fico de Barras. 4 Variables, 4 barras.
// Estas variables ser&aacute;n usadas para representar los valores de cada unas de las 4 barras.
// Inicializo las variables a utilizar.

require_once('dbconnect.php');
	
	$conn = new MySQLConn();
	$conn->connect();
	$generos = $_REQUEST['genero'];
	
	$fechasis= date('Y-m-d');
	
	
	$sql="SELECT COUNT(categoria) FROM t_compe2014 WHERE genero = '".$generos."' AND categoria='14-19 Juvenil'";
	$conn->sqlQuery($sql);
	$filas1 = $conn->rows[0];
	
	$sql="SELECT COUNT(categoria) FROM t_compe2014 WHERE genero = '".$generos."' AND categoria='20-39 Senior'";
	$conn->sqlQuery($sql);
	$filas2 = $conn->rows[0];
	
	$sql="SELECT COUNT(categoria) FROM t_compe2014 WHERE genero = '".$generos."' AND categoria='40-49 Master'";
	$conn->sqlQuery($sql);
	$filas3 = $conn->rows[0];

	$sql="SELECT COUNT(categoria) FROM t_compe2014 WHERE genero = '".$generos."' AND categoria='50-59 Super Master'";
	$conn->sqlQuery($sql);
	$filas4 = $conn->rows[0];

	$sql="SELECT COUNT(categoria) FROM t_compe2014 WHERE genero = '".$generos."' AND categoria='Miguelitos 60+'";
	$conn->sqlQuery($sql);
	$filas5 = $conn->rows[0];

	

// $strXML: Para concatenar los par&aacute;metros finales para el gr&aacute;fico.
$strXML = "";
// Armo los par&aacute;metros para el gr&aacute;fico. Todos estos datos se concatenan en una variable.
// Encabezado de la variable XML. Comienza con la etiqueta "Chart".
// caption: define el t&iacute;tulo del gr&aacute;fico.
// bgColor: define el color de fondo que tendr&aacute; el gr&aacute;fico.
// baseFontSize: Tama&ntilde;o de la fuente que se usar&aacute; en el gr&aacute;fico.
// showValues: = 1 indica que se mostrar&aacute;n los valores de cada barra. = 0 No mostrar&aacute; los valores en el gr&aacute;fico.
// xAxisName: define el texto que ir&aacute; sobre el eje X. Abajo del gr&aacute;fico. Tambi&eacute;n est&aacute; xAxisName.
$strXML = "<chart caption = 'Gr�fico Estad�stico CATEGORIAS' bgColor='#FFFFFF' baseFontSize='12' showValues='1' xAxisName='CATEGORIAS'  yAxisName='CANTIDAD'>";
// Armado de cada barra.
// set label: asigno el nombre de cada barra.
// value: asigno el valor para cada barra.
// color: color que tendr&aacute; cada barra. Si no lo defino, tomar&aacute; colores por defecto.
$strXML .= "<set label = '14-19 Juvenil' value ='".$filas1."' color = 'EA1000' />";
$strXML .= "<set label = '20-39 Senior' value ='".$filas2."' color = '6D8D16' />";
$strXML .= "<set label = '40-49 Master' value ='".$filas3."' color = 'FFBA00' />";
$strXML .= "<set label = '50-59 Super Master' value ='".$filas4."' color = '0000FF' />";
$strXML .= "<set label = 'Miguelitos 60+' value ='".$filas5."' color = '0000FF' />";


// Cerramos la etiqueta "chart".
$strXML .= "</chart>";
echo renderChartHTML("Column3D.swf", "",$strXML, "ejemplo", 650, 500, false);
?>        </td>
        <td width="90">&nbsp;</td>
      </tr>
    </table>    </td>
  </tr>
  <tr bordercolor="#FFFFFF" bgcolor="#FFFFFF">
    <td colspan="2" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
</table>
<p>&nbsp;</p>
</body>
</html>
