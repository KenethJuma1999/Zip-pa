
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Sistema Odontologico</title>
<LINK REL="SHORTCUT ICON" HREF="http://localhost/reserv/images/favicon.ico">

<style type="text/css">

<!--

/* Gradient 2 */
.tb7 {
	width: 221px;
	background: transparent url('images/bg.jpg') no-repeat;
	color : #747862;
	height:20px;
	border:0;
	padding:4px 8px;
	margin-bottom:0px;
}
.fb7 {
    background: #EBE3CD no-repeat 5px center;
    vertical-align:middle; 
    border: 1px solid #969184;
}
.Estilo7 {color: #FFFFFF; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 11px; font-weight: bold; }
.Estilo8 {color: #FFFFFF}




body {
	background-color: #D6EDF2;
	background-image: url(images/atomos_web_ok.png);
}
.Estilo9 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 11px;
}
.Estilo11 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 11px; font-weight: bold; }
-->
</style>
<script language="JavaScript">

var speed = 100 
var pause = 3000
var timerID = null
var bannerRunning = false
var ar = new Array()
ar[0] = "Sistema de reservaciones Online..."
ar[1] = "Reserve y Planifique a Tiempo....."
ar[2] = "Consultas y Reportes 100% Rapidas."
ar[3] = "Copyright 2011 Audit & Planning S.A."
var currentMessage = 0
var offset = 0
function stopBanner() {
if (bannerRunning)
clearTimeout(timerID)
bannerRunning = false
}
function startBanner() {
stopBanner()
showBanner()
}
function showBanner() {
var text = ar[currentMessage]
if (offset < text.length) {
if (text.charAt(offset) == " ")
offset++ 
var partialMessage = text.substring(0, offset + 1) 
window.status = partialMessage
offset++ // IE sometimes has trouble with "++offset"
timerID = setTimeout("showBanner()", speed)
bannerRunning = true
} else {
offset = 0
currentMessage++
if (currentMessage == ar.length)
currentMessage = 0
timerID = setTimeout("showBanner()", pause)
bannerRunning = true
}
}
startBanner();
// -->
</script>
<script language="JavaScript">
<!--

   function event_false() {
         window.event.returnValue = false
   }

document.onselectstart = event_false

//-->
</script>
</head>


<body>
<script language="javascript" type="text/javascript">

function MostrarFecha()
   {
   var nombres_dias = new Array("Domingo", "Lunes", "Martes", "Mi�rcoles", "Jueves", "Viernes", "S�bado")
   var nombres_meses = new Array("Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre")
   var fecha_actual = new Date()
   dia_mes = fecha_actual.getDate()		     //dia del mes
   dia_semana = fecha_actual.getDay()		//dia de la semana
   mes = fecha_actual.getMonth() + 1
   anio = fecha_actual.getFullYear()
  //escribe en pagina
   document.write(nombres_dias[dia_semana] + ", " + dia_mes + " de " + nombres_meses[mes - 1] + " de " + anio)
   }
</script>
<script language="JavaScript1.2">
<!--
function notice(){
menutext.style.left=document.body.scrollLeft+event.clientX
menutext.style.top=document.body.scrollTop+event.clientY
menutext.style.visibility="visible"
return false
}
function hidenotice(){
menutext.style.visibility="hidden"
}
//-->
</script>
<!--[if IE]>
<div id="menutext"><div url=""></div></div>
<![endif]-->
<script language="JavaScript1.2">
<!--
document.oncontextmenu=notice;
if (document.all&&window.print)
document.body.onclick=hidenotice;
//-->
</script>
<p>&nbsp;</p>
<table width="1126" height="164" border="0" align="center" bordercolor="#FFFFFF" bgcolor="#FFFFFF">
  
  <tr bordercolor="#FFFFFF" bgcolor="#FFFFFF">
    <td width="687" bordercolor="#FFFFFF" bgcolor="#FFFFFF">&nbsp;</td>
    <td width="429">&nbsp;</td>
  </tr>
  <tr bordercolor="#FFFFFF" bgcolor="#FFFFFF">
    <td colspan="2"><table width="1056" border="0" align="center">
      <tr>
        <td width="123">&nbsp;</td>
        <td width="594">
<?php
// archivos incluidos. Librer&iacute;as PHP para poder graficar.
include "FusionCharts.php";
include "Functions.php";
// Gr&aacute;fico de Barras. 4 Variables, 4 barras.
// Estas variables ser&aacute;n usadas para representar los valores de cada unas de las 4 barras.
// Inicializo las variables a utilizar.

require_once('dbconnect.php');
	
	$conn = new MySQLConn();
	$conn->connect();
	$anoss = $_REQUEST['ano'];
	$mess = $_REQUEST['mes'];
	
	$fechasis= date('Y/m/d');
	$fecha =$fechasis; 
	$partes = explode("-", $fecha);
	$fechaproy1=$anoss."/".$mess."/"."01";		$fechaproy2=$anoss."/".$mess."/"."02";
	$fechaproy3=$anoss."/".$mess."/"."03";		$fechaproy4=$anoss."/".$mess."/"."04";
	$fechaproy5=$anoss."/".$mess."/"."05";		$fechaproy6=$anoss."/".$mess."/"."06";
	$fechaproy7=$anoss."/".$mess."/"."07";		$fechaproy8=$anoss."/".$mess."/"."08";
	$fechaproy9=$anoss."/".$mess."/"."09";		$fechaproy10=$anoss."/".$mess."/"."10";
	$fechaproy11=$anoss."/".$mess."/"."11";		$fechaproy12=$anoss."/".$mess."/"."12";
	$fechaproy13=$anoss."/".$mess."/"."13";		$fechaproy14=$anoss."/".$mess."/"."14";
	$fechaproy15=$anoss."/".$mess."/"."15";		$fechaproy16=$anoss."/".$mess."/"."16";
	$fechaproy17=$anoss."/".$mess."/"."17";		$fechaproy18=$anoss."/".$mess."/"."18";
	$fechaproy19=$anoss."/".$mess."/"."19";		$fechaproy20=$anoss."/".$mess."/"."20";
	
	$fechaproy21=$anoss."/".$mess."/"."21";		$fechaproy22=$anoss."/".$mess."/"."22";
	$fechaproy23=$anoss."/".$mess."/"."23";		$fechaproy24=$anoss."/".$mess."/"."24";
	$fechaproy25=$anoss."/".$mess."/"."25";		$fechaproy26=$anoss."/".$mess."/"."26";
	$fechaproy27=$anoss."/".$mess."/"."27";		$fechaproy28=$anoss."/".$mess."/"."28";
	$fechaproy29=$anoss."/".$mess."/"."29";		$fechaproy30=$anoss."/".$mess."/"."30";
	
	$fechaproy31=$anoss."/".$mess."/"."31";

	
	$sql="select SUM(valor_factura) from factura where fecha_factura='$fechaproy1';";
	$conn->sqlQuery($sql);
	$filas1 = $conn->rows[0];
	$filas111= round (($filas1),2);
	
	$sql="select SUM(valor_factura) from factura where fecha_factura='$fechaproy2';";
	$conn->sqlQuery($sql);
	$filas2 = $conn->rows[0];
	$filas222= round (($filas2),2);

	$sql="select SUM(valor_factura) from factura where fecha_factura='$fechaproy3';";
	$conn->sqlQuery($sql);
	$filas3 = $conn->rows[0];
	$filas333= round (($filas3),2);
	
	$sql="select SUM(valor_factura) from factura where fecha_factura='$fechaproy4';";
	$conn->sqlQuery($sql);
	$filas4 = $conn->rows[0];
	$filas444= round (($filas4),2);

	$sql="select SUM(valor_factura) from factura where fecha_factura='$fechaproy5';";
	$conn->sqlQuery($sql);
	$filas5 = $conn->rows[0];
	$filas555= round (($filas5),2);
	
	$sql="select SUM(valor_factura) from factura where fecha_factura='$fechaproy6';";
	$conn->sqlQuery($sql);
	$filas6 = $conn->rows[0];
	$filas666= round (($filas6),2);
	
	$sql="select SUM(valor_factura) from factura where fecha_factura='$fechaproy7';";
	$conn->sqlQuery($sql);
	$filas7 = $conn->rows[0];
	$filas777= round (($filas7),2);
	
	$sql="select SUM(valor_factura) from factura where fecha_factura='$fechaproy8';";
	$conn->sqlQuery($sql);
	$filas8 = $conn->rows[0];
	$filas888= round (($filas8),2);
	
	$sql="select SUM(valor_factura) from factura where fecha_factura='$fechaproy9';";
	$conn->sqlQuery($sql);
	$filas9 = $conn->rows[0];
	$filas999= round (($filas9),2);
	
	$sql="select SUM(valor_factura) from factura where fecha_factura='$fechaproy10';";
	$conn->sqlQuery($sql);
	$filas10 = $conn->rows[0];
	$filas100= round (($filas10),2);
	
	$sql="select SUM(valor_factura) from factura where fecha_factura='$fechaproy11';";
	$conn->sqlQuery($sql);
	$filas11 = $conn->rows[0];
	$filas1111= round (($filas11),2);
	
	$sql="select SUM(valor_factura) from factura where fecha_factura='$fechaproy12';";
	$conn->sqlQuery($sql);
	$filas12 = $conn->rows[0];
	$filas1212= round (($filas12),2);
	
	$sql="select SUM(valor_factura) from factura where fecha_factura='$fechaproy13';";
	$conn->sqlQuery($sql);
	$filas13 = $conn->rows[0];
	$filas1313= round (($filas13),2);
	
	$sql="select SUM(valor_factura) from factura where fecha_factura='$fechaproy14';";
	$conn->sqlQuery($sql);
	$filas14 = $conn->rows[0];
	$filas1414= round (($filas14),2);
	
	$sql="select SUM(valor_factura) from factura where fecha_factura='$fechaproy15';";
	$conn->sqlQuery($sql);
	$filas15 = $conn->rows[0];
	$filas1515= round (($filas15),2);
	
	$sql="select SUM(valor_factura) from factura where fecha_factura='$fechaproy16';";
	$conn->sqlQuery($sql);
	$filas16 = $conn->rows[0];
	$filas1616= round (($filas16),2);
	
	$sql="select SUM(valor_factura) from factura where fecha_factura='$fechaproy17';";
	$conn->sqlQuery($sql);
	$filas17 = $conn->rows[0];
	$filas1717= round (($filas17),2);
	
	$sql="select SUM(valor_factura) from factura where fecha_factura='$fechaproy18';";
	$conn->sqlQuery($sql);
	$filas18 = $conn->rows[0];
	$filas1818= round (($filas18),2);
	
	$sql="select SUM(valor_factura) from factura where fecha_factura='$fechaproy19';";
	$conn->sqlQuery($sql);
	$filas19 = $conn->rows[0];
	$filas1919= round (($filas19),2);
	
	$sql="select SUM(valor_factura) from factura where fecha_factura='$fechaproy20';";
	$conn->sqlQuery($sql);
	$filas20 = $conn->rows[0];
	$filas2020= round (($filas20),2);
	
	$sql="select SUM(valor_factura) from factura where fecha_factura='$fechaproy21';";
	$conn->sqlQuery($sql);
	$filas21 = $conn->rows[0];
	$filas2121= round (($filas21),2);
	
	$sql="select SUM(valor_factura) from factura where fecha_factura='$fechaproy22';";
	$conn->sqlQuery($sql);
	$filas22 = $conn->rows[0];
	$filas2222= round (($filas22),2);
	
		$sql="select SUM(valor_factura) from factura where fecha_factura='$fechaproy23';";
	$conn->sqlQuery($sql);
	$filas23 = $conn->rows[0];
	$filas2323= round (($filas23),2);
	
		$sql="select SUM(valor_factura) from factura where fecha_factura='$fechaproy24';";
	$conn->sqlQuery($sql);
	$filas24 = $conn->rows[0];
	$filas2424= round (($filas24),2);
	
	$sql="select SUM(valor_factura) from factura where fecha_factura='$fechaproy25';";
	$conn->sqlQuery($sql);
	$filas25 = $conn->rows[0];
	$filas2525= round (($filas25),2);
	
	$sql="select SUM(valor_factura) from factura where fecha_factura='$fechaproy26';";
	$conn->sqlQuery($sql);
	$filas26 = $conn->rows[0];
	$filas266= round (($filas26),2);
	
	$sql="select SUM(valor_factura) from factura where fecha_factura='$fechaproy27';";
	$conn->sqlQuery($sql);
	$filas27 = $conn->rows[0];
	$filas2727= round (($filas27),2);
	
	$sql="select SUM(valor_factura) from factura where fecha_factura='$fechaproy28';";
	$conn->sqlQuery($sql);
	$filas28 = $conn->rows[0];
	$filas2828= round (($filas28),2);
	
	$sql="select SUM(valor_factura) from factura where fecha_factura='$fechaproy29';";
	$conn->sqlQuery($sql);
	$filas29 = $conn->rows[0];
	$filas2929= round (($filas29),2);
	
	$sql="select SUM(valor_factura) from factura where fecha_factura='$fechaproy30';";
	$conn->sqlQuery($sql);
	$filas30 = $conn->rows[0];
	$filas3030= round (($filas30),2);
	
	$sql="select SUM(valor_factura) from factura where fecha_factura='$fechaproy31';";
	$conn->sqlQuery($sql);
	$filas31 = $conn->rows[0];
	$filas3131= round (($filas31),2);
	
	
	

$intTotalAnio1 = $filas;
$intTotalAnio2 = $filas11;
$intTotalAnio3 = $filas2;
$intTotalAnio4 = $filas5;
$intTotalAnio5 = $filas6;

// $strXML: Para concatenar los par&aacute;metros finales para el gr&aacute;fico.
$strXML = "";
// Armo los par&aacute;metros para el gr&aacute;fico. Todos estos datos se concatenan en una variable.
// Encabezado de la variable XML. Comienza con la etiqueta "Chart".
// caption: define el t&iacute;tulo del gr&aacute;fico.
// bgColor: define el color de fondo que tendr&aacute; el gr&aacute;fico.
// baseFontSize: Tama&ntilde;o de la fuente que se usar&aacute; en el gr&aacute;fico.
// showValues: = 1 indica que se mostrar&aacute;n los valores de cada barra. = 0 No mostrar&aacute; los valores en el gr&aacute;fico.
// xAxisName: define el texto que ir&aacute; sobre el eje X. Abajo del gr&aacute;fico. Tambi&eacute;n est&aacute; xAxisName.
$strXML = "<chart caption = 'Gr�fico Estad�stico Mensual de Facturacion' bgColor='#FFFFFF' baseFontSize='12' showValues='1' xAxisName='Dias'  yAxisName='Dolares $'>";
// Armado de cada barra.
// set label: asigno el nombre de cada barra.
// value: asigno el valor para cada barra.
// color: color que tendr&aacute; cada barra. Si no lo defino, tomar&aacute; colores por defecto.
$strXML .= "<set label = 'D1' value ='".$filas111."' color = 'EA1000' />";
$strXML .= "<set label = 'D2' value ='".$filas222."' color = '6D8D16' />";
$strXML .= "<set label = 'D3' value ='".$filas333."' color = 'FFBA00' />";
$strXML .= "<set label = 'D4' value ='".$filas444."' color = '0000FF' />";
$strXML .= "<set label = 'D5' value ='".$filas555."' color = '0000FF' />";
$strXML .= "<set label = 'D6' value ='".$filas666."' color = 'EA1000' />";
$strXML .= "<set label = 'D7' value ='".$filas777."' color = '6D8D16' />";
$strXML .= "<set label = 'D8' value ='".$filas888."' color = 'FFBA00' />";
$strXML .= "<set label = 'D9' value ='".$filas999."' color = '0000FF' />";
$strXML .= "<set label = 'D10' value ='".$filas100."' color = '0000FF' />";

$strXML .= "<set label = 'D11' value ='".$filas1111."' color = 'FFBA00' />";
$strXML .= "<set label = 'D12' value ='".$filas1212."' color = '0000FF' />";
$strXML .= "<set label = 'D13' value ='".$filas1313."' color = '0000FF' />";
$strXML .= "<set label = 'D14' value ='".$filas1414."' color = 'EA1000' />";
$strXML .= "<set label = 'D15' value ='".$filas1515."' color = '6D8D16' />";
$strXML .= "<set label = 'D16' value ='".$filas1616."' color = 'FFBA00' />";
$strXML .= "<set label = 'D17' value ='".$filas1717."' color = '0000FF' />";
$strXML .= "<set label = 'D18' value ='".$filas1818."' color = '0000FF' />";
$strXML .= "<set label = 'D19' value ='".$filas1919."' color = 'EA1000' />";
$strXML .= "<set label = 'D20' value ='".$filas2020."' color = '6D8D16' />";


$strXML .= "<set label = 'D21' value ='".$filas2121."' color = 'FFBA00' />";
$strXML .= "<set label = 'D22' value ='".$filas2222."' color = '0000FF' />";
$strXML .= "<set label = 'D23' value ='".$filas2323."' color = '0000FF' />";
$strXML .= "<set label = 'D24' value ='".$filas2424."' color = 'EA1000' />";
$strXML .= "<set label = 'D25' value ='".$filas2525."' color = '6D8D16' />";
$strXML .= "<set label = 'D26' value ='".$filas266."' color = 'FFBA00' />";
$strXML .= "<set label = 'D27' value ='".$filas2727."' color = '0000FF' />";
$strXML .= "<set label = 'D28' value ='".$filas2828."' color = '0000FF' />";
$strXML .= "<set label = 'D29' value ='".$filas2929."' color = 'EA1000' />";
$strXML .= "<set label = 'D30' value ='".$filas3030."' color = '6D8D16' />";
$strXML .= "<set label = 'D31' value ='".$filas3131."' color = '6D8D16' />";


// Cerramos la etiqueta "chart".
$strXML .= "</chart>";
echo renderChartHTML("Column3D.swf", "",$strXML, "ejemplo", 1000, 600, false);
?>        </td>
        <td width="90">&nbsp;</td>
      </tr>
    </table>    </td>
  </tr>
  <tr bordercolor="#FFFFFF" bgcolor="#FFFFFF">
    <td colspan="2" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
</table>
<p>&nbsp;</p>
</body>
</html>
