<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Documento sin t&iacute;tulo</title>
<style type="text/css">
<!--
body {
	background-image: url(images/background3.png);
}
.Estilo5 {font-size: 10px; color: #1D4296; font-weight: bold; }
.Estilo9 {	font-size: 12px;
	color: #1D4296;
	font-weight: bold;
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
.style1 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12; }
.Estilo10 {font-size: 10px; color: #1D4296; font-weight: bold; font-family: Verdana, Arial, Helvetica, sans-serif; }
.style5 {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 24px;
	font-weight: bold;
}
.Estilo11 {color: #FFFFFF}
-->
</style></head>

<body>
<p>&nbsp;</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="18%">&nbsp;</td>
    <td width="62%"><div align="center"><img src="images/logout.png" width="225" height="225" /></div></td>
    <td width="20%">&nbsp;</td>
  </tr>
</table>
<p align="right">&nbsp;</p>
<p align="right" class="Estilo10"><img src="images/cam.PNG" width="68" height="19" /></p>
<p align="right" class="Estilo10">Software del Ecuador </p>
</body>
</html>
