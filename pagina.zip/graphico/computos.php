<?php
session_start();
ob_start();
if (!isset($_SESSION['sesion_cedula'])){
	header("location:error1.php");
	return;
}
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<LINK href="estilonet.css" type=text/css rel=stylesheet>
<script type="text/javascript" src="js/rounded-corners.js"></script>
<script type="text/javascript" src="js/form-field-tooltip.js"></script>
<title>VotoElectr�nico Maestros Asociados LTDA</title>
<style type="text/css">
<!--
.Estilo14 {color: #000000}
.Estilo2 {font-size: 12px;
	font-weight: bold;
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
#Layer1 {
	position:absolute;
	left:98px;
	top:497px;
	width:162px;
	height:19px;
	z-index:1;
}
-->
</style>

<SCRIPT language=JavaScript>
  <!--
  function click() {
    if (event.button==2) {
      alert('Copyright 2009 COAC')
    }
  }
  document.onmousedown=click
  // -->
</SCRIPT>

</head>

<body>
<table width="801" border="0" align="center" cellpadding="0" cellspacing="0" style="border-width: 0px" >
  <!-- fwtable fwsrc="pepe_final.png" fwbase="pepe_final.jpg" fwstyle="Dreamweaver" fwdocid = "1835410485" fwnested="0" -->
  <tr>
    <td valign="top" width="801">
	<img border="0" src="archivos/demo.jpg" width="806" height="140"></td>
  </tr>
  <tr>
    <td valign="top" width="801">
	<table width="96%" height="272"  border="0" id="table4">
      <tr>
        <td height="232" bordercolor="#FFFFFF" bgcolor="#FFFFFF" style="border-style: none; border-width: medium"><table width="798" border="0" align="center">
          <tr>
            <td width="114">&nbsp;</td>
            <td width="633">
<?php
// archivos incluidos. Librer&iacute;as PHP para poder graficar.
include "FusionCharts.php";
include "Functions.php";
require_once('dbconnect.php');
	
	$conn = new MySQLConn();
	$conn->connect();

	$sql="select * from persona;";
	$conn->sqlQuery($sql);
	$filas = $conn->num_rows;
	
	$pc = ($filas*100)/$filas ;
	
	
	$sql1="select * from persona where estado_voto ='V';";
	$conn->sqlQuery($sql1);
	$filas1 = $conn->num_rows;
	$pc1 = ($filas1*100)/$filas ;
	
	
	$sql2="select * from persona where estado_voto ='F';";
	$conn->sqlQuery($sql2);
	$filas2 = $conn->num_rows;
	$pc2 = ($filas2*100)/$filas ;
	
	$sql3 = "SELECT sum(voto.votos) FROM persona, voto  WHERE persona.cod_mat = voto.cod_mat and candidatura='Principal'" ;
	$conn->sqlQuery($sql3);
	$filas4 = $conn->rows[0];
	$pc3 = ($filas4*100)/$filas4 ;

	
	/////// OJO PONER CUALQUIER NOMBRE DE UN PRINCIPAL ////////////////////////////////
	$sql4 = "SELECT sum(voto.votos_blancos) FROM persona, voto  WHERE persona.cod_mat = voto.cod_mat and nombres='Julio Miguel'" ;
	$conn->sqlQuery($sql4);
	$filas5 = $conn->rows[0];
    $pc4 = ($filas5*100)/$filas ;
	
	$sql5 = "SELECT sum(voto.votos_nulos) FROM persona, voto  WHERE persona.cod_mat = voto.cod_mat and nombres='Julio Miguel'" ;
	$conn->sqlQuery($sql5);
	$filas6 = $conn->rows[0];
    $pc5 = round(($filas6*100)/$filas,2) ;

$intTotalAnio1 = $filas;
$intTotalAnio2 = $filas1;
$intTotalAnio3 = $filas2;
$intTotalAnio4 = $filas4;
$intTotalAnio5 = $filas5;
$intTotalAnio6 = $filas6;

// $strXML: Para concatenar los par&aacute;metros finales para el gr&aacute;fico.
$strXML = "";
$strXML = "<chart caption = 'Reportes de Voto Electronico' bgColor='#FFFFFF' baseFontSize='12' showValues='1' xAxisName='Votos' >";
$strXML .= "<set label = 'Nro. Votantes' value ='".$intTotalAnio1."' color = 'EA1000' />";
$strXML .= "<set label = 'Si Sufragan' value ='".$intTotalAnio2."' color = '6D8D16' />";
$strXML .= "<set label = 'No Sufragan' value ='".$intTotalAnio3."' color = 'FFBA00' />";
$strXML .= "<set label = 'Votos Validos' value ='".$intTotalAnio4."' color = '666699' />";
$strXML .= "<set label = 'Votos Blancos' value ='".$intTotalAnio5."' color = '0000FF' />";
$strXML .= "<set label = 'Votos Nulos' value ='".$intTotalAnio6."' color = '663333' />";

// Cerramos la etiqueta "chart".
$strXML .= "</chart>";
echo renderChartHTML("Column3D.swf", "",$strXML, "ejemplo", 500, 400, false);
?></td>
            <td width="29">&nbsp;</td>
          </tr>
        </table>
          <p align="center"><a href="../webmaster.php">Regresar</a></p></td>
      </tr>
      <tr>
        <td height="13" valign="top">
		<img border="0" src="archivos/abajo.gif" width="801" height="140"></td>
      </tr>
      </table></td>
  </tr>
</table>
</body>
</html>
