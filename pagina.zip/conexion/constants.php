<?php
define ("HOST" , "localhost");
define ("USER" , "root");
define ("PWD" , "");
define ("DATABASE" , "biblioteca");
?>